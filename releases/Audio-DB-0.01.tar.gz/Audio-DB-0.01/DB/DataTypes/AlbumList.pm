package Audio::DB::DataTypes::AlbumList;
use strict 'vars';
use vars '@ISA';
#use Audio::DB::Web;
#@ISA = qw/Audio::DB::Web/;

1;
