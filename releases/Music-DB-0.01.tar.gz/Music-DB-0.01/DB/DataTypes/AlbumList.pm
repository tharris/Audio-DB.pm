package Music::DB::DataTypes::AlbumList;
use strict 'vars';
use vars '@ISA';
#use Music::DB::Web;
#@ISA = qw/Music::DB::Web/;

1;
